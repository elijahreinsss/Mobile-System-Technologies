package com.example.matchupgame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.matchupgame.ui.theme.MatchUpGameTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MatchUpGameTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MemoryGame()
                }
            }
        }
    }
}

data class CardItem(
    val id: Int,
    val imageRes: Int,
    val isFaceUp: Boolean = false,
    val isMatched: Boolean = false
)

fun generateCards(): List<CardItem> {
    val images = listOf(
        R.drawable.card1,
        R.drawable.card2,
        R.drawable.card3,
        R.drawable.card4,
        R.drawable.card5,
        R.drawable.card6
    )
    val pairedImages = (images + images).shuffled()
    return pairedImages.mapIndexed { index, imageRes ->
        CardItem(id = index, imageRes = imageRes)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryGame() {
    var cards by remember { mutableStateOf(generateCards()) }
    var selectedIndices by remember { mutableStateOf(emptyList<Int>()) }
    val scope = rememberCoroutineScope()

    val columns = 3
    val rows = cards.size / columns

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Match Up") },
                actions = {
                    IconButton(onClick = {
                        cards = generateCards()
                        selectedIndices = emptyList()
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Restart")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            for (row in 0 until rows) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (col in 0 until columns) {
                        val index = row * columns + col
                        val card = cards[index]

                        Box(
                            modifier = Modifier
                                .padding(8.dp)
                                .size(90.dp)
                                .clickable(
                                    enabled = !card.isFaceUp && !card.isMatched && selectedIndices.size < 2
                                ) {
                                    cards = cards.toMutableList().also {
                                        it[index] = it[index].copy(isFaceUp = true)
                                    }
                                    selectedIndices = selectedIndices + index

                                    if (selectedIndices.size == 2) {
                                        scope.launch {
                                            delay(800)
                                            val first = cards[selectedIndices[0]]
                                            val second = cards[selectedIndices[1]]

                                            cards = cards.toMutableList().also {
                                                if (first.imageRes == second.imageRes) {
                                                    it[selectedIndices[0]] = it[selectedIndices[0]].copy(isMatched = true)
                                                    it[selectedIndices[1]] = it[selectedIndices[1]].copy(isMatched = true)
                                                } else {
                                                    it[selectedIndices[0]] = it[selectedIndices[0]].copy(isFaceUp = false)
                                                    it[selectedIndices[1]] = it[selectedIndices[1]].copy(isFaceUp = false)
                                                }
                                            }
                                            selectedIndices = emptyList()
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(
                                    id = if (card.isFaceUp || card.isMatched)
                                        card.imageRes else R.drawable.back
                                ),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GamePreview() {
    MatchUpGameTheme {
        MemoryGame()
    }
}
