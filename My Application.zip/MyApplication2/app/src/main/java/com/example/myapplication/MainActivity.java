package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText et1, et2, et3;
    Button bt;

    String myPreferences = "MyPrefs";
    String name = "nameKey";
    String password = "passKey";
    String email = "emailKey";

    SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        et1 = findViewById(R.id.editText1);
        et2 = findViewById(R.id.editText2);
        et3 = findViewById(R.id.editText3);
        bt = findViewById(R.id.button1);

        // Set up SharedPreferences
        sharedPref = getSharedPreferences(myPreferences, Context.MODE_PRIVATE);

        // Save data on  click
        bt.setOnClickListener(v -> {
            String n = et1.getText().toString();
            String pw = et2.getText().toString();
            String e = et3.getText().toString();

            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString(name, n);
            editor.putString(password, pw);
            editor.putString(email, e);
            editor.apply(); // or editor.commit()

            Toast.makeText(MainActivity.this, "Thanks", Toast.LENGTH_LONG).show();
        });
    }
}
