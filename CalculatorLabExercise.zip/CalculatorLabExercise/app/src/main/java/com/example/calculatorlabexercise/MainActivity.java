package com.example.calculatorlabexercise;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private String currentInput = "";
    private String operator = "";
    private double firstNumber = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
    }

    public void onNumberClick(View view) {
        Button button = (Button) view;
        currentInput += button.getText().toString();
        display.setText(currentInput);
    }

    public void onOperatorClick(View view) {
        if (!currentInput.isEmpty()) {
            firstNumber = Double.parseDouble(currentInput);
            Button button = (Button) view;
            operator = button.getText().toString();
            display.setText(currentInput + " " + operator);  // Show number and operator
            currentInput = "";
        }
    }

    public void onequalsClick(View view) {
        if (!currentInput.isEmpty() && !operator.isEmpty()) {
            double secondNumber = Double.parseDouble(currentInput);
            double result = 0;

            switch (operator) {
                case "+":
                    result = firstNumber + secondNumber;
                    break;
                case "-":
                    result = firstNumber - secondNumber;
                    break;
                case "*":
                    result = firstNumber * secondNumber;
                    break;
                case "/":
                    if (secondNumber != 0) {
                        result = firstNumber / secondNumber;
                    } else {
                        display.setText("Error");
                        return;
                    }
                    break;
                case "%":
                    result = (firstNumber * secondNumber) / 100;
                    break;
            }

            if (result == (int) result) {
                display.setText(currentInput + " " + operator + " " + (int) secondNumber + " = " + (int) result);
            } else {
                display.setText(currentInput + " " + operator + " " + secondNumber + " = " + result);
            }

            currentInput = String.valueOf(result);
            operator = "";
        }
    }

    public void onClearClick(View view) {
        currentInput = "";
        display.setText(currentInput);
    }

    public void onClearAllClick(View view) {
        currentInput = "";
        operator = "";
        firstNumber = 0;
        display.setText("");
    }

    public void onDeleteClick(View view) {
        if (!currentInput.isEmpty()) {
            currentInput = currentInput.substring(0, currentInput.length() - 1);
            display.setText(currentInput);
        }
    }
}
